document.addEventListener("DOMContentLoaded", function () {
    // 🎬 Movie Slider
    const movieSlider = document.querySelector(".movie-slider");
    const moviePrev = document.querySelector(".prev");
    const movieNext = document.querySelector(".next");

    let movieScrollAmount = 0;
    let movieScrollStep = 300; // Adjust width
    let movieMaxScroll = movieSlider.scrollWidth - movieSlider.clientWidth;
    let movieAutoSlide;

    function moveMovieSlider() {
        movieSlider.scrollTo({ left: movieScrollAmount, behavior: "smooth" });
    }

    function nextMovieSlide() {
        if (movieScrollAmount < movieMaxScroll) {
            movieScrollAmount += movieScrollStep;
            moveMovieSlider();
        } else {
            movieScrollAmount = 0;
            moveMovieSlider();
        }
    }

    function prevMovieSlide() {
        if (movieScrollAmount > 0) {
            movieScrollAmount -= movieScrollStep;
            moveMovieSlider();
        }
    }

    function startMovieAutoSlide() {
        movieAutoSlide = setInterval(nextMovieSlide, 3000);
    }

    function stopMovieAutoSlide() {
        clearInterval(movieAutoSlide);
    }

    movieNext.addEventListener("click", function () {
        stopMovieAutoSlide();
        nextMovieSlide();
        startMovieAutoSlide();
    });

    moviePrev.addEventListener("click", function () {
        stopMovieAutoSlide();
        prevMovieSlide();
        startMovieAutoSlide();
    });

    movieSlider.addEventListener("mouseenter", stopMovieAutoSlide);
    movieSlider.addEventListener("mouseleave", startMovieAutoSlide);

    startMovieAutoSlide(); // Start movie auto slider

    // 🎭 Actor Slider
    const actorSlider = document.querySelector(".actors-slider");
    const actorPrev = document.querySelector(".prev-actor");
    const actorNext = document.querySelector(".next-actor");

    let actorScrollAmount = 0;
    let actorScrollStep = 180;
    let actorMaxScroll = actorSlider.scrollWidth - actorSlider.clientWidth;

    actorNext.addEventListener("click", function () {
        if (actorScrollAmount < actorMaxScroll) {
            actorScrollAmount += actorScrollStep;
            actorSlider.scrollTo({ left: actorScrollAmount, behavior: "smooth" });
        }
    });

    actorPrev.addEventListener("click", function () {
        if (actorScrollAmount > 0) {
            actorScrollAmount -= actorScrollStep;
            actorSlider.scrollTo({ left: actorScrollAmount, behavior: "smooth" });
        }
    });

    // 🎬 Movie Click Event - Open Movie Details Page
    document.querySelectorAll(".movie img").forEach((img) => {
        img.addEventListener("click", function () {
            const movieName = this.alt.replace(/\s+/g, "-").toLowerCase();
            window.location.href = `movies/${movieName}.html`;
        });
    });

    // 🎭 Dropdown Menu
    const dropdown = document.querySelector(".dropdown");
    const dropdownMenu = document.querySelector(".dropdown-menu");

    dropdown.addEventListener("click", () => {
        dropdownMenu.classList.toggle("show");
    });

    document.addEventListener("click", (event) => {
        if (!dropdown.contains(event.target)) {
            dropdownMenu.classList.remove("show");
        }
    });
});
document.addEventListener("DOMContentLoaded", function () {
    const actorsSlider = document.querySelector(".actors-slider");
    let scrollAmount = 0;
    const scrollStep = 200; // Adjust this for scroll speed
    const maxScroll = actorsSlider.scrollWidth - actorsSlider.clientWidth;

    function autoScrollActors() {
        if (scrollAmount >= maxScroll) {
            scrollAmount = 0; // Reset to the beginning when reaching the end
        } else {
            scrollAmount += scrollStep;
        }
        actorsSlider.scrollTo({
            left: scrollAmount,
            behavior: "smooth",
        });
    }

    // Auto-scroll every 3 seconds
    setInterval(autoScrollActors, 1000);
});